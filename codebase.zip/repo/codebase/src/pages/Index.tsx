import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Search,
  Star,
  Check,
  Clock,
  Calendar,
  MapPin,
  Play,
  ShieldCheck,
  Lock,
  Eye,
  BadgeCheck,
  Wallet,
  Repeat,
  Plus,
  Minus,
  CalendarClock,
  ChevronRight,
} from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { courseImages } from "../data/courses";

/* ---------------- Hero ---------------- */
function Hero() {
  const navigate = useNavigate();
  return (
    <section className="bg-pale-blue">
      <div className="mx-auto grid max-w-[1200px] items-center gap-10 px-6 py-16 lg:grid-cols-2 lg:py-20">
        <div>
          <h1 className="font-display text-[44px] font-extrabold leading-[1.05] tracking-[-0.02em] text-navy sm:text-[56px] lg:text-[68px]">
            The smarter way to book <span className="text-teal">driving lessons</span>
          </h1>
          <p className="mt-6 max-w-md text-[16px] text-muted-slate">
            Search thousands of DVSA-approved instructors near you
          </p>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              navigate("/courses");
            }}
            className="mt-8 flex max-w-md items-center gap-2 rounded-2xl border border-border-blue bg-white p-2 shadow-sm"
          >
            <input
              type="text"
              name="address"
              placeholder="Type your pick up address.."
              aria-label="Pick-up address"
              className="flex-1 bg-transparent px-3 py-2 text-[15px] text-navy outline-none"
            />
            <button
              type="submit"
              className="flex items-center gap-2 rounded-xl bg-navy px-5 py-3 text-[13px] font-bold uppercase tracking-wide text-white transition-opacity duration-150 hover:opacity-90"
            >
              <Search size={16} /> Search
            </button>
          </form>

          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              to="/courses"
              className="rounded-lg bg-navy px-6 py-3 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
            >
              Find an instructor
            </Link>
            <Link
              to="/reviews"
              className="rounded-lg border border-navy/20 px-6 py-3 text-[15px] font-bold text-navy transition-colors duration-150 hover:border-navy"
            >
              See reviews →
            </Link>
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-2 text-[14px] text-muted-slate">
            <span className="flex text-amber">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={16} fill="currentColor" strokeWidth={0} />
              ))}
            </span>
            <span className="font-bold text-navy">4.9 average</span>
            <span>· Rated by 6,499+ learners</span>
            <span className="hidden text-border-blue sm:inline">|</span>
            <span>Pay later with</span>
            <span className="rounded-md bg-[#ffb3c7] px-2 py-0.5 text-[12px] font-bold text-navy">Klarna</span>
            <span className="rounded-md bg-[#b2fce4] px-2 py-0.5 text-[12px] font-bold text-navy">Clearpay</span>
          </div>
        </div>

        {/* Hero visuals */}
        <div className="relative mx-auto hidden h-[440px] w-full max-w-[520px] lg:block">
          <div className="absolute right-4 top-6 h-[300px] w-[320px] rounded-3xl bg-teal/60" />
          <img
            src="/018a9_1782279781401.png"
            alt="Instructor teaching"
            className="absolute right-0 top-0 h-[360px] w-[420px] rounded-3xl object-cover shadow-xl"
          />
          <img
            src="/63842_1782893473948.jpg"
            alt="On the road"
            className="absolute bottom-0 left-0 h-[280px] w-[300px] -rotate-6 rounded-3xl border-4 border-white object-cover shadow-2xl"
          />
          <div className="absolute right-6 top-2 flex items-center gap-3 rounded-xl bg-white px-4 py-3 shadow-lg">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-teal text-white">
              <Check size={16} />
            </span>
            <div className="leading-tight">
              <p className="text-[13px] font-bold text-navy">Test passed</p>
              <p className="text-[12px] text-muted-slate">First time · 8 hrs ago</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Instructors ---------------- */
function Instructors() {
  return (
    <section className="bg-white">
      <div className="mx-auto grid max-w-[1200px] items-center gap-12 px-6 py-20 lg:grid-cols-2">
        <div className="relative">
          <img
            src="/bc673_learner-lplates.webp"
            alt="Learner holding L plates"
            className="w-full rounded-3xl object-cover shadow-lg"
          />
          <div className="absolute -bottom-8 left-6 w-[280px] rounded-xl bg-white p-4 shadow-xl">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-deep-blue text-[13px] font-bold text-white">
                VT
              </span>
              <div className="leading-tight">
                <p className="text-[13px] font-bold text-navy">V2 TEST INSTRUCTOR 2 (DO NOT USE)</p>
                <p className="text-[12px] text-muted-slate">UK</p>
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2 text-[13px] text-muted-slate">
              <span className="flex text-amber">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={13} fill="currentColor" strokeWidth={0} />
                ))}
              </span>
              4.9 · DBS checked
            </div>
          </div>
        </div>

        <div className="mt-8 lg:mt-0">
          <h2 className="font-display text-[36px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[52px]">
            See who's teaching you <span className="text-teal">before you book.</span>
          </h2>
          <p className="mt-6 max-w-lg text-[16px] leading-relaxed text-muted-slate">
            Every instructor on EveryDriver is DVSA approved, DBS checked and personally vetted.
            Compare real reviews, live availability and pass rates — then pick the one that fits you.
          </p>
          <Link
            to="/instructors"
            className="mt-6 inline-flex items-center gap-1 border-b-2 border-teal-deep pb-1 text-[15px] font-bold text-teal-deep"
          >
            Meet the instructors →
          </Link>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Routes ---------------- */
const routeCards = [
  { tag: "FAST TRACK", title: "Intensive Course", price: "£1,299", sub: "Pass in 1–2 weeks", popular: false },
  { tag: "MOST POPULAR", title: "Semi-Intensive", price: "£999", sub: "Pass in 2–4 weeks", popular: true },
  { tag: "FLEXIBLE", title: "Weekly Lessons", price: "£30/hr", sub: "Pass at your own pace", popular: false },
];

function Routes() {
  return (
    <section className="bg-pale-blue">
      <div className="mx-auto grid max-w-[1200px] items-center gap-12 px-6 py-20 lg:grid-cols-2">
        <div>
          <h2 className="font-display text-[36px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[44px]">
            Pick the route that <span className="text-teal">fits your life.</span>
          </h2>
          <p className="mt-6 max-w-lg text-[16px] leading-relaxed text-muted-slate">
            Pass fast on an intensive, balance speed with practice on a semi-intensive, or learn at
            your own pace with weekly lessons. Free re-test, free theory test and Klarna or Clearpay
            on every route.
          </p>
          <ul className="mt-6 space-y-3">
            {[
              "Free re-test if you don't pass",
              "Free theory test included",
              "DVSA-approved instructors only",
            ].map((item) => (
              <li key={item} className="flex items-center gap-3 text-[15px] text-navy">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-teal text-white">
                  <Check size={14} />
                </span>
                {item}
              </li>
            ))}
          </ul>
          <Link
            to="/courses?view=pricing"
            className="mt-6 inline-flex items-center gap-1 border-b-2 border-teal-deep pb-1 text-[15px] font-bold text-teal-deep"
          >
            Compare all routes →
          </Link>
        </div>

        <div className="space-y-4">
          {routeCards.map((c) => (
            <div
              key={c.title}
              className={`rounded-2xl border bg-white p-6 shadow-sm ${
                c.popular ? "border-teal ring-1 ring-teal" : "border-border-blue"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[12px] font-bold uppercase tracking-wide text-teal-deep">
                  {c.tag}
                </span>
                {c.popular && (
                  <span className="rounded-full bg-teal/15 px-3 py-1 text-[12px] font-bold text-teal-deep">
                    Popular
                  </span>
                )}
              </div>
              <div className="mt-3 flex items-end justify-between">
                <div>
                  <h3 className="font-display text-[22px] font-extrabold text-navy">{c.title}</h3>
                  <p className="mt-1 text-[14px] text-muted-slate">{c.sub}</p>
                </div>
                <span className="font-display text-[26px] font-extrabold text-navy">{c.price}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Stats ---------------- */
const stats = [
  { figure: "10,000+", label: "Pupils taught" },
  { figure: "92%", label: "Pass rate" },
  { figure: "4.9", label: "Avg. rating" },
  { figure: "1,200+", label: "Instructors" },
];

function Stats() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-[1000px] px-6 py-20 text-center">
        <h2 className="mx-auto max-w-2xl font-display text-[30px] font-extrabold leading-[1.15] tracking-[-0.01em] text-navy sm:text-[40px]">
          We've helped thousands of learners pass with confidence.
        </h2>
        <div className="mt-12 grid grid-cols-2 gap-8 md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label}>
              <p className="font-display text-[44px] font-extrabold text-teal-deep sm:text-[56px]">
                {s.figure}
              </p>
              <p className="mt-2 text-[15px] text-muted-slate">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Route Tabs (dark) ---------------- */
const tabs = [
  {
    key: "Intensive Course",
    label: "MOST POPULAR",
    heading: "Intensive Course",
    sub: "Pass in 1–2 weeks",
    features: ["Fastest route to your licence", "Book test week included", "FREE Re-Test if you fail", "Ideal for confident learners"],
    price: "£1,299",
    cta: "View intensive",
    to: "/intensives",
  },
  {
    key: "Semi-Intensive",
    label: "MOST POPULAR",
    heading: "Semi-Intensive",
    sub: "Pass in 2–4 weeks",
    features: ["Balanced speed & practice", "Flexible scheduling", "FREE Re-Test if you fail", "Time to practise"],
    price: "£999",
    cta: "View semi-intensive",
    to: "/semi-intensive",
  },
  {
    key: "Weekly Lessons",
    label: "FLEXIBLE",
    heading: "Weekly Lessons",
    sub: "Pass at your own pace",
    features: ["Learn week by week", "Fits around your life", "FREE Re-Test if you fail", "Great for beginners"],
    price: "£30/hr",
    cta: "View weekly lessons",
    to: "/courses",
  },
];

function RouteTabs() {
  const [active, setActive] = useState(1);
  const t = tabs[active];
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-[1200px] px-6 py-10">
        <div className="rounded-3xl bg-navy p-8 sm:p-12">
          <h2 className="max-w-2xl font-display text-[32px] font-extrabold leading-[1.1] tracking-[-0.02em] text-white sm:text-[44px]">
            The flexible driving journey for every learner.
          </h2>
          <p className="mt-4 max-w-lg text-[16px] text-white/70">
            Choose the route your life fits around — and switch at any point.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            {tabs.map((tab, i) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActive(i)}
                className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-[14px] font-semibold transition-colors duration-150 ${
                  active === i ? "bg-teal text-navy" : "bg-white/10 text-white hover:bg-white/20"
                }`}
              >
                {active === i ? <Minus size={16} /> : <Plus size={16} />}
                {tab.key}
              </button>
            ))}
          </div>

          <div className="mt-8 grid gap-8 lg:grid-cols-2">
            <div>
              <span className="text-[12px] font-bold uppercase tracking-wide text-teal">{t.label}</span>
              <h3 className="mt-2 font-display text-[28px] font-extrabold text-white sm:text-[36px]">
                {t.heading}
              </h3>
              <p className="mt-1 text-[15px] text-white/70">{t.sub}</p>
              <ul className="mt-6 space-y-3">
                {t.features.map((f) => (
                  <li key={f} className="flex items-center gap-3 text-[15px] text-white/90">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-teal/25 text-teal">
                      <Check size={14} />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                to={t.to}
                className="mt-8 inline-block rounded-lg bg-teal px-6 py-3 text-[15px] font-bold text-navy transition-opacity duration-150 hover:opacity-90"
              >
                {t.cta}
              </Link>
            </div>

            <div className="rounded-2xl bg-white p-8">
              <p className="text-[13px] font-bold uppercase tracking-wide text-muted-slate">From</p>
              <p className="mt-1 font-display text-[44px] font-extrabold text-teal-deep">{t.price}</p>
              <div className="mt-4 flex items-center gap-2 text-[14px] text-muted-slate">
                Spread the cost
                <span className="rounded-md bg-[#ffb3c7] px-2 py-0.5 text-[12px] font-bold text-navy">Klarna</span>
                <span className="rounded-md bg-[#b2fce4] px-2 py-0.5 text-[12px] font-bold text-navy">Clearpay</span>
              </div>
              <ul className="mt-6 space-y-3 border-t border-border-blue pt-6">
                {["Free re-test if you don't pass", "Free theory test included", "DVSA approved instructors"].map(
                  (f) => (
                    <li key={f} className="flex items-center gap-3 text-[15px] text-navy">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-teal text-white">
                        <Check size={14} />
                      </span>
                      {f}
                    </li>
                  )
                )}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Story + Video ---------------- */
function Story() {
  const [playing, setPlaying] = useState(false);
  return (
    <section className="bg-white">
      <div className="mx-auto grid max-w-[1200px] items-center gap-12 px-6 py-20 lg:grid-cols-2">
        <div>
          <h2 className="font-display text-[36px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[56px]">
            Every Driver has a story ...
          </h2>
          <p className="mt-6 max-w-lg text-[16px] leading-relaxed text-muted-slate">
            See what to expect from booking your first lesson to passing your test.
          </p>
          <Link
            to="/courses"
            className="mt-6 inline-block rounded-lg bg-navy px-6 py-3 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
          >
            Find a course
          </Link>
        </div>

        <div className="overflow-hidden rounded-3xl border border-border-blue bg-pale-blue">
          <div className="relative aspect-video">
            {playing ? (
              <iframe
                title="Welcome to the EveryDriver story."
                src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1"
                className="h-full w-full"
                allow="autoplay; encrypted-media"
                allowFullScreen
              />
            ) : (
              <button
                type="button"
                onClick={() => setPlaying(true)}
                className="group flex h-full w-full flex-col items-center justify-center bg-navy text-white"
              >
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-teal text-navy transition-transform duration-150 group-hover:scale-105">
                  <Play size={26} fill="currentColor" />
                </span>
                <span className="mt-4 text-[13px] font-bold uppercase tracking-wide text-teal">Play now</span>
              </button>
            )}
          </div>
          <div className="flex items-center justify-between p-5">
            <div>
              <h3 className="font-display text-[16px] font-bold text-navy">
                Welcome to the EveryDriver story.
              </h3>
              <p className="mt-1 text-[13px] text-muted-slate">
                Learn more about how Every Driver can support you..
              </p>
            </div>
            <div className="flex items-center gap-2 text-[12px] font-bold">
              <span className="text-muted-slate">Watch now</span>
              <span className="rounded-full bg-teal/15 px-2 py-0.5 text-teal-deep">Free</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Protected (3 cards) ---------------- */
const protectedCards = [
  {
    Icon: Eye,
    title: "Checked & monitored",
    body: "All instructors verified before joining and continuously monitored. Every one abides by the DVSA Code of Conduct.",
  },
  {
    Icon: ShieldCheck,
    title: "Enhanced DBS",
    body: "Highest level background check — includes children's and adults' barred lists for total peace of mind.",
  },
  {
    Icon: Lock,
    title: "Your money is safe",
    body: "Funds held securely until your booking is confirmed. No instructor gets paid until you're booked in.",
  },
];

function Protected() {
  return (
    <section className="bg-pale-blue">
      <div className="mx-auto max-w-[1200px] px-6 py-20">
        <div className="max-w-2xl">
          <h2 className="font-display text-[32px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[44px]">
            Your journey, protected at every turn.
          </h2>
          <p className="mt-6 text-[16px] leading-relaxed text-muted-slate">
            Search vetted instructors near you, compare reviews and live availability, then book
            online 24/7 — all backed by EveryDriver.
          </p>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {protectedCards.map(({ Icon, title, body }) => (
            <div key={title} className="rounded-2xl border border-border-blue bg-white p-8">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal/15 text-teal-deep">
                <Icon size={22} />
              </span>
              <h3 className="mt-5 font-display text-[20px] font-extrabold text-navy">{title}</h3>
              <p className="mt-3 text-[15px] leading-relaxed text-muted-slate">{body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- How it works ---------------- */
const howItems = [
  { Icon: Calendar, title: "Book online 24/7", body: "Real availability from vetted instructors — no phone tag, no back and forth." },
  { Icon: Wallet, title: "Transparent pricing", body: "See the price up front. No hidden fees, no last-minute surprises." },
  { Icon: Repeat, title: "Free re-test cover", body: "Protected tiers include a free re-test if you don't pass first time." },
  { Icon: BadgeCheck, title: "One place for everything", body: "Lessons, progress, payments and messages — all in your learner portal." },
  { Icon: ShieldCheck, title: "Vetted instructors only", body: "Enhanced DBS, ADI-registered and continuously monitored for quality." },
  { Icon: Lock, title: "Money held safely", body: "Your payment is protected until your booking is confirmed with an instructor." },
];

function HowItWorks() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-[1200px] px-6 py-20">
        <span className="text-[12px] font-bold uppercase tracking-wide text-teal-deep">
          Why EveryDriver
        </span>
        <div className="mt-3 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-xl">
            <h2 className="font-display text-[32px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[44px]">
              A smarter way to book your lessons.
            </h2>
            <p className="mt-6 text-[16px] leading-relaxed text-muted-slate">
              We built EveryDriver to take the stress out of learning to drive — one platform for
              finding, booking and managing everything from your first lesson to test day.
            </p>
          </div>
          <div className="flex gap-3">
            <Link
              to="/courses"
              className="rounded-lg bg-navy px-6 py-3 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
            >
              Find a course
            </Link>
            <Link
              to="/courses"
              className="rounded-lg border border-border-blue px-6 py-3 text-[15px] font-bold text-navy transition-colors duration-150 hover:border-navy"
            >
              How it works
            </Link>
          </div>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {howItems.map(({ Icon, title, body }) => (
            <div key={title} className="rounded-2xl border border-border-blue bg-pale-blue p-6">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white text-teal-deep">
                <Icon size={20} />
              </span>
              <h3 className="mt-4 font-display text-[18px] font-bold text-navy">{title}</h3>
              <p className="mt-2 text-[14px] leading-relaxed text-muted-slate">{body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Test Swap ---------------- */
const swapSteps = [
  { title: "Register", sub: "Your test date" },
  { title: "Match", sub: "Find a swap" },
  { title: "Swap", sub: "With DVSA" },
  { title: "Confirmed", sub: "DVSA sends confirmation" },
];

function TestSwap() {
  return (
    <section className="bg-pale-blue">
      <div className="mx-auto grid max-w-[1200px] items-center gap-12 px-6 py-20 lg:grid-cols-2">
        <div className="relative order-2 lg:order-1">
          <div className="rounded-3xl bg-navy p-8">
            <div className="rounded-xl bg-white p-4 shadow-lg">
              <p className="text-[12px] font-bold uppercase tracking-wide text-teal-deep">New date found</p>
              <p className="mt-1 font-display text-[18px] font-bold text-navy">Tue 14 Jul · 10:40</p>
              <p className="text-[13px] text-muted-slate">Southampton Maybush · 6 weeks earlier</p>
            </div>
            <div className="mt-4 flex w-fit items-center gap-3 rounded-xl bg-teal px-4 py-3 text-navy shadow-lg">
              <CalendarClock size={20} />
              <div className="leading-tight">
                <p className="text-[12px] font-bold uppercase tracking-wide">Free swap</p>
                <p className="text-[13px]">Others charge £25</p>
              </div>
            </div>
          </div>
        </div>

        <div className="order-1 lg:order-2">
          <span className="text-[12px] font-bold uppercase tracking-wide text-teal-deep">
            Free test swap service
          </span>
          <h2 className="mt-3 font-display text-[32px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[46px]">
            Cut months off your test wait.
          </h2>
          <p className="mt-6 max-w-lg text-[16px] leading-relaxed text-muted-slate">
            We match you with another learner who has the test date you want, then handle the DVSA
            swap for you — free, safe and unlimited. No £25 fees like the other guys.
          </p>
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {swapSteps.map((s, i) => (
              <div key={s.title} className="rounded-xl border border-border-blue bg-white p-4">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-teal/15 text-[13px] font-bold text-teal-deep">
                  {i + 1}
                </span>
                <p className="mt-3 text-[14px] font-bold text-navy">{s.title}</p>
                <p className="text-[12px] text-muted-slate">{s.sub}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link
              to="/test-swap"
              className="rounded-lg bg-navy px-6 py-3 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
            >
              Register for test swap
            </Link>
            <span className="text-[14px] text-muted-slate">No fee · Unlimited swaps</span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Featured courses ---------------- */
const featured = [
  { title: "test course 29th june", date: "01/07/2026", postcode: "SO30 2TD", hours: "800h", price: "From £2,000", featured: true },
  { title: "28 Hour Intensive + Test", date: "01/07/2026", postcode: "SO22 5DB", hours: "28h", price: "From £99,999", featured: true },
  { title: "10 Hour Intensive", date: "28/08/2026", postcode: "SO22 4AA", hours: "10h", price: "From £1", featured: false },
  { title: "10 Hour Intensive", date: "27/08/2026", postcode: "SO22 4AA", hours: "10h", price: "From £1", featured: false },
  { title: "10 Hour Intensive", date: "17/08/2026", postcode: "SO22 4AA", hours: "10h", price: "From £1", featured: false },
  { title: "8 Hour Intensive", date: "27/08/2026", postcode: "SO30 2AA", hours: "8h", price: "From £9,000", featured: false },
];

function Featured() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-[1200px] px-6 py-20">
        <span className="text-[12px] font-bold uppercase tracking-wide text-teal-deep">Available now</span>
        <div className="mt-3 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div className="max-w-2xl">
            <h2 className="font-display text-[32px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[44px]">
              Featured courses near you.
            </h2>
            <p className="mt-4 text-[16px] leading-relaxed text-muted-slate">
              Hand-picked intensive and semi-intensive courses with verified DBS-checked
              instructors. Deposit protected, re-test guarantee included.
            </p>
          </div>
          <Link
            to="/courses"
            className="whitespace-nowrap text-[15px] font-bold text-teal-deep"
          >
            View all courses →
          </Link>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {featured.map((c, i) => (
            <div
              key={i}
              className="overflow-hidden rounded-2xl border border-border-blue bg-white shadow-sm transition-shadow duration-150 hover:shadow-lg"
            >
              <div
                className="relative h-44 bg-cover bg-center"
                style={{ backgroundImage: `url(${courseImages[i % courseImages.length]})` }}
              >
                {c.featured && (
                  <span className="absolute left-3 top-3 rounded-full bg-navy px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-teal">
                    ★ Featured
                  </span>
                )}
              </div>
              <div className="p-5">
                <p className="text-[13px] text-muted-slate">with Ken D</p>
                <h3 className="mt-1 font-display text-[18px] font-bold text-navy">{c.title}</h3>
                <div className="mt-4 space-y-2 text-[13px] text-muted-slate">
                  <p className="flex items-center gap-2"><Calendar size={14} /> {c.date}</p>
                  <p className="flex items-center gap-2"><MapPin size={14} /> {c.postcode}</p>
                  <p className="flex items-center gap-2"><Clock size={14} /> {c.hours}</p>
                </div>
                <div className="mt-4 flex items-center justify-between border-t border-border-blue pt-4">
                  <span className="font-display text-[18px] font-extrabold text-navy">{c.price}</span>
                  <Link to="/courses" className="text-[14px] font-bold text-teal-deep">
                    Book now →
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Testimonials ---------------- */
const testimonials = [
  { quote: "Passed first time thanks to my amazing instructor!", name: "Sarah J.", meta: "Eastleigh · Passed first time", avatar: "/1f323_1782279952120.png", initials: null },
  { quote: "Booking was easy and the lessons were brilliant.", name: "Tom B.", meta: "Southampton · Semi-intensive", avatar: null, initials: "TB" },
  { quote: "Highly recommend — felt confident on test day.", name: "Priya K.", meta: "Winchester · Test swap user", avatar: null, initials: "PK" },
];

function Testimonials() {
  return (
    <section className="bg-pale-blue">
      <div className="mx-auto max-w-[1200px] px-6 py-20">
        <h2 className="font-display text-[32px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[44px]">
          What our learners say.
        </h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="flex flex-col rounded-2xl border border-border-blue bg-white p-8">
              <span className="flex text-amber">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={16} fill="currentColor" strokeWidth={0} />
                ))}
              </span>
              <p className="mt-4 flex-1 text-[16px] leading-relaxed text-navy">"{t.quote}"</p>
              <div className="mt-6 flex items-center gap-3">
                {t.avatar ? (
                  <img src={t.avatar} alt={t.name} className="h-11 w-11 rounded-full object-cover" />
                ) : (
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-deep-blue text-[13px] font-bold text-white">
                    {t.initials}
                  </span>
                )}
                <div className="leading-tight">
                  <p className="text-[14px] font-bold text-navy">{t.name}</p>
                  <p className="text-[13px] text-muted-slate">{t.meta}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- News ---------------- */
function News() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-[1200px] px-6 py-20">
        <span className="text-[12px] font-bold uppercase tracking-wide text-teal-deep">
          Latest from EveryDriver
        </span>
        <div className="mt-3 flex items-end justify-between">
          <h2 className="font-display text-[32px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[44px]">
            News & tips.
          </h2>
          <Link to="/news" className="whitespace-nowrap text-[15px] font-bold text-teal-deep">
            View all articles →
          </Link>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          <Link
            to="/news"
            className="group overflow-hidden rounded-2xl border border-border-blue bg-white shadow-sm transition-shadow duration-150 hover:shadow-lg md:col-span-2"
          >
            <div
              className="h-56 bg-cover bg-center"
              style={{ backgroundImage: "url(/1aa0d_1781855568133-orudtyon.png)" }}
            />
            <div className="p-6">
              <span className="text-[11px] font-bold uppercase tracking-wide text-teal-deep">News</span>
              <h3 className="mt-2 font-display text-[20px] font-bold text-navy">dfsfds</h3>
              <p className="mt-2 text-[13px] text-muted-slate">19 Jun 2026 · 3 min read</p>
            </div>
          </Link>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FAQ ---------------- */
const faqs = [
  {
    q: "How does the free re-test guarantee work?",
    a: "If you don't pass on protected course tiers, we cover the cost of your next test so you can try again without extra fees.",
  },
  {
    q: "What's included in the free theory test?",
    a: "Every eligible course includes your theory test booking plus revision resources to help you prepare with confidence.",
  },
  {
    q: "Are instructors insured and fully qualified?",
    a: "Yes — all instructors are ADI-registered, Enhanced DBS checked and fully insured before they can teach on EveryDriver.",
  },
  {
    q: "Can I spread the cost with Klarna or Clearpay?",
    a: "Absolutely. You can pay in instalments with Klarna or Clearpay at checkout on every route.",
  },
  {
    q: "What if I'm not happy with my instructor?",
    a: "Let us know and we'll match you with another vetted instructor near you. Your booking stays protected throughout.",
  },
];

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="bg-pale-blue">
      <div className="mx-auto max-w-[900px] px-6 py-20">
        <span className="text-[12px] font-bold uppercase tracking-wide text-teal-deep">FAQ</span>
        <h2 className="mt-3 font-display text-[34px] font-extrabold leading-[1.1] tracking-[-0.02em] text-navy sm:text-[48px]">
          Frequently asked questions.
        </h2>
        <p className="mt-4 text-[16px] text-muted-slate">
          Quick answers to the things people ask us most. Can't find what you need? Get in touch.
        </p>

        <div className="mt-10">
          <h3 className="font-display text-[20px] font-bold text-navy">Common questions</h3>
          <p className="mt-2 text-[15px] text-muted-slate">
            Everything you need to know before booking a driving course with EveryDriver.
          </p>
          <div className="mt-6 space-y-3">
            {faqs.map((f, i) => {
              const isOpen = open === i;
              return (
                <div key={i} className="rounded-xl border border-faq-border bg-white">
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpen(isOpen ? null : i)}
                    className={`flex w-full items-center justify-between gap-4 px-5 py-4 text-left text-[16px] font-semibold transition-colors duration-150 ${
                      isOpen ? "text-faq-question-open" : "text-faq-question"
                    }`}
                  >
                    {f.q}
                    <Plus
                      size={18}
                      className={`shrink-0 text-faq-accent transition-transform duration-200 ${
                        isOpen ? "rotate-45" : ""
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <p className="px-5 pb-5 text-[15px] leading-relaxed text-faq-answer">{f.a}</p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- CTA duo ---------------- */
function CTADuo() {
  return (
    <section className="bg-white">
      <div className="mx-auto grid max-w-[1200px] gap-6 px-6 py-20 md:grid-cols-2">
        <div className="rounded-3xl bg-navy p-10">
          <h3 className="font-display text-[24px] font-extrabold text-white">Find a course</h3>
          <p className="mt-4 text-[15px] leading-relaxed text-white/70">
            Enter your postcode to see intensive, semi-intensive and weekly courses from vetted
            instructors near you.
          </p>
          <Link
            to="/courses"
            className="mt-6 inline-flex items-center gap-2 rounded-lg bg-teal px-6 py-3 text-[15px] font-bold text-navy transition-opacity duration-150 hover:opacity-90"
          >
            Browse courses <ChevronRight size={16} />
          </Link>
        </div>
        <div className="rounded-3xl border border-border-blue bg-pale-blue p-10">
          <h3 className="font-display text-[24px] font-extrabold text-navy">Get an earlier test</h3>
          <p className="mt-4 text-[15px] leading-relaxed text-muted-slate">
            Others charge £25. Our test swap matches you with a learner who has the date you want —
            completely free.
          </p>
          <Link
            to="/test-swap"
            className="mt-6 inline-flex items-center gap-2 rounded-lg bg-navy px-6 py-3 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
          >
            Register for test swap <ChevronRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}

const Index = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <Instructors />
        <Routes />
        <Stats />
        <RouteTabs />
        <Story />
        <Protected />
        <HowItWorks />
        <TestSwap />
        <Featured />
        <Testimonials />
        <News />
        <FAQ />
        <CTADuo />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
