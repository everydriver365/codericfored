import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, Clock, Calendar, Star, Zap, MapPin } from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";

type IntensiveCourse = {
  day: string;
  month: string;
  title: string;
  dateLabel: string;
  postcode: string;
  price: number;
};

const intensiveImages = [
  "/897618dd1416-db35425470_asset.jpg",
  "/902ed_1781853333038-iv3mth.png",
  "/1aa0d_1781855568133-orudtyon.png",
];

const intensiveCourses: IntensiveCourse[] = [
  { day: "1", month: "JUL", title: "test course 29th june", dateLabel: "1 Jul 2026", postcode: "SO30 2TD", price: 2000 },
  { day: "1", month: "JUL", title: "28 Hour Intensive + Test", dateLabel: "1 Jul 2026", postcode: "SO22 5DB", price: 99999 },
  { day: "26", month: "JUN", title: "28 Hour Intensive + Test", dateLabel: "26 Jun 2026", postcode: "SO22 4AD", price: 200 },
  { day: "1", month: "AUG", title: "10 Hour Intensive", dateLabel: "1 Aug 2026", postcode: "BB1 9LP", price: 2000 },
  { day: "22", month: "JUN", title: "10 Hour Intensive", dateLabel: "22 Jun 2026", postcode: "SO22 5DB", price: 522 },
  { day: "22", month: "JUN", title: "test course 20th june", dateLabel: "22 Jun 2026", postcode: "SO22 4AA", price: 12121 },
  { day: "17", month: "AUG", title: "10 Hour Intensive", dateLabel: "17 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "18", month: "AUG", title: "10 Hour Intensive", dateLabel: "18 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "19", month: "AUG", title: "10 Hour Intensive", dateLabel: "19 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "20", month: "AUG", title: "10 Hour Intensive", dateLabel: "20 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "21", month: "AUG", title: "10 Hour Intensive", dateLabel: "21 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "24", month: "AUG", title: "10 Hour Intensive", dateLabel: "24 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "25", month: "AUG", title: "10 Hour Intensive", dateLabel: "25 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "26", month: "AUG", title: "10 Hour Intensive", dateLabel: "26 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "27", month: "AUG", title: "10 Hour Intensive", dateLabel: "27 Aug 2026", postcode: "SO30 0AE", price: 500 },
  { day: "28", month: "AUG", title: "10 Hour Intensive", dateLabel: "28 Aug 2026", postcode: "SO30 0AE", price: 500 },
];

const heroCards = [
  { Icon: Clock, title: "Quick results", sub: "Pass in as little as 5–7 days" },
  { Icon: Calendar, title: "Flexible dates", sub: "Start dates to suit your schedule" },
  { Icon: Star, title: "High pass rate", sub: "90%+ first-time pass rate" },
];

function IntensiveCard({ c, i }: { c: IntensiveCourse; i: number }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-border-blue bg-white shadow-sm transition-shadow duration-150 hover:shadow-lg">
      <div
        className="relative h-44 bg-cover bg-center"
        style={{ backgroundImage: `url(${intensiveImages[i % intensiveImages.length]})` }}
      >
        <div className="absolute left-3 top-3 flex gap-2">
          <span className="rounded-full bg-navy px-3 py-1 text-[11px] font-semibold text-white">Intensive</span>
          <span className="rounded-full bg-white px-3 py-1 text-[11px] font-semibold text-navy">Manual</span>
        </div>
      </div>
      <div className="flex">
        <div className="flex w-20 shrink-0 flex-col items-center justify-center bg-navy py-6 text-white">
          <span className="font-display text-[26px] font-extrabold leading-none">{c.day}</span>
          <span className="mt-1 text-[12px] uppercase tracking-wide">{c.month}</span>
        </div>
        <div className="flex-1 p-5">
          <h3 className="font-display text-[15px] font-bold text-navy">{c.title}</h3>
          <p className="mt-2 text-[13px] text-muted-slate">Flexible · {c.dateLabel}</p>
          <p className="mt-2 flex items-center gap-2 text-[13px] text-muted-slate">
            <MapPin size={14} className="text-teal-deep" /> {c.postcode}
          </p>
          <p className="mt-2 flex items-center gap-1 text-[13px] text-muted-slate">
            <Star size={14} className="text-amber" fill="currentColor" strokeWidth={0} /> 4.9
          </p>
          <div className="mt-4 flex items-center justify-between">
            <span className="font-display text-[18px] font-extrabold text-navy">£{c.price.toLocaleString("en-GB")}</span>
            <Link to="/courses" className="rounded-lg bg-navy px-4 py-2 text-[13px] font-bold text-white transition-opacity duration-150 hover:opacity-90">
              Book now
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

const Intensives = () => {
  const navigate = useNavigate();
  const [address, setAddress] = useState("");

  return (
    <div className="min-h-screen bg-pale-blue">
      <Header />

      {/* Hero */}
      <section className="bg-navy">
        <div className="mx-auto max-w-[1200px] px-6 py-16">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-[12px] font-bold uppercase tracking-wide text-teal">
            <Zap size={14} /> Fast-track your licence
          </span>
          <h1 className="mt-6 font-display text-[40px] font-extrabold leading-[1.05] tracking-[-0.02em] text-white sm:text-[54px]">
            Intensive driving courses.
          </h1>
          <p className="mt-5 max-w-xl text-[16px] leading-relaxed text-white/70">
            Pass your driving test in as little as one week. Perfect for busy schedules or urgent
            driving needs.
          </p>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {heroCards.map(({ Icon, title, sub }) => (
              <div key={title} className="flex items-center gap-3 rounded-xl bg-white/5 p-4 ring-1 ring-white/10">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-teal/20 text-teal">
                  <Icon size={20} />
                </span>
                <div className="leading-tight">
                  <p className="text-[15px] font-bold text-white">{title}</p>
                  <p className="text-[13px] text-white/70">{sub}</p>
                </div>
              </div>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              navigate("/courses");
            }}
            className="mt-8 flex max-w-lg items-center gap-2 rounded-2xl bg-white p-2 shadow-lg"
          >
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Type your pick up address.."
              aria-label="Pick-up address"
              className="flex-1 bg-transparent px-3 py-2 text-[15px] text-navy outline-none"
            />
            <button
              type="submit"
              className="flex items-center gap-2 rounded-xl bg-navy px-5 py-3 text-[13px] font-bold uppercase tracking-wide text-white transition-opacity duration-150 hover:opacity-90"
            >
              <Search size={16} /> Search
            </button>
          </form>
        </div>
      </section>

      {/* Courses grid */}
      <main className="mx-auto max-w-[1200px] px-6 py-14">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {intensiveCourses.map((c, i) => (
            <IntensiveCard key={i} c={c} i={i} />
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Intensives;
