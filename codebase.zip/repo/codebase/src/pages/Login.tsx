import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Please enter your email and password.");
      return;
    }
    setError("");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-pale-blue">
      <Header />
      <main className="mx-auto flex max-w-[1200px] items-start justify-center px-6 py-16">
        <div className="w-full max-w-md rounded-2xl border border-border-blue bg-white p-8 shadow-sm sm:p-10">
          <h1 className="font-display text-[26px] font-bold text-navy">Sign in</h1>
          <p className="mt-2 text-[15px] text-muted-slate">Welcome back to EveryDriver.</p>

          <form onSubmit={onSubmit} className="mt-8 space-y-4">
            <input
              type="email"
              name="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              aria-label="Email"
              className="w-full rounded-lg border border-border-blue px-4 py-3 text-[15px] text-navy outline-none focus:border-teal-deep"
            />
            <input
              type="password"
              name="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              aria-label="Password"
              className="w-full rounded-lg border border-border-blue px-4 py-3 text-[15px] text-navy outline-none focus:border-teal-deep"
            />
            {error && <p className="text-[14px] text-red-600">{error}</p>}
            <button
              type="submit"
              className="w-full rounded-lg bg-navy px-5 py-3 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
            >
              Sign in
            </button>
          </form>

          <p className="mt-6 text-center text-[14px] text-muted-slate">
            New here?{" "}
            <Link to="/login" className="font-bold text-navy">
              Create an account
            </Link>
          </p>

          <div className="my-6 flex items-center gap-3 text-[13px] text-muted-slate">
            <span className="h-px flex-1 bg-border-blue" />
            or
            <span className="h-px flex-1 bg-border-blue" />
          </div>

          <p className="text-center text-[14px] text-muted-slate">Never received your setup email?</p>
          <Link
            to="/login"
            className="mt-3 block rounded-lg border border-teal-deep px-5 py-3 text-center text-[15px] font-bold text-teal-deep transition-colors duration-150 hover:bg-pale-blue"
          >
            Request access →
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Login;
