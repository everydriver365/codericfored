import { Link } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";

const NotFound = () => {
  return (
    <div className="min-h-screen bg-pale-blue">
      <Header />
      <main className="mx-auto flex max-w-[1200px] flex-col items-center justify-center px-6 py-32 text-center">
        <p className="font-display text-[72px] font-extrabold leading-none text-teal-deep">404</p>
        <h1 className="mt-4 font-display text-[28px] font-extrabold text-navy">Page not found</h1>
        <p className="mt-3 max-w-md text-[16px] text-muted-slate">
          The page you're looking for doesn't exist or has moved. Let's get you back on the road.
        </p>
        <Link
          to="/"
          className="mt-8 rounded-lg bg-navy px-6 py-3 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
        >
          Back to home
        </Link>
      </main>
      <Footer />
    </div>
  );
};

export default NotFound;
