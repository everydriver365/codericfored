import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  Search,
  MapPin,
  Clock,
  User,
  Crosshair,
  LayoutGrid,
  List,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { courses, courseImages, gbp, type Course } from "../data/courses";

const hourFilters = ["All", "10hrs", "20hrs", "28hrs (Test week)", "30hrs", "40hrs"];
const radiusOptions = ["1 mile", "3 miles", "5 miles", "10 miles", "15 miles", "20 miles", "30 miles"];
const sortOptions = ["Soonest", "Price: Low to high", "Nearest"];

const hourValue: Record<string, number | null> = {
  All: null,
  "10hrs": 10,
  "20hrs": 20,
  "28hrs (Test week)": 28,
  "30hrs": 30,
  "40hrs": 40,
};

/* Sept 2026 days that have courses available */
const sepDays = courses
  .filter((c) => c.month === "SEP")
  .map((c) => parseInt(c.day, 10));

function Calendar() {
  // September 2026 starts on a Tuesday
  const leadingBlanks = 1; // Mon empty, Sep 1 = Tue
  const cells: (number | null)[] = [
    ...Array.from({ length: leadingBlanks }, () => null),
    ...Array.from({ length: 30 }, (_, i) => i + 1),
  ];
  return (
    <div className="rounded-2xl border border-border-blue bg-white p-5">
      <div className="flex items-center justify-between">
        <button type="button" aria-label="Previous month" className="text-muted-slate hover:text-navy">
          <ChevronLeft size={18} />
        </button>
        <span className="text-[14px] font-bold text-navy">September 2026</span>
        <button type="button" aria-label="Next month" className="text-muted-slate hover:text-navy">
          <ChevronRight size={18} />
        </button>
      </div>
      <div className="mt-4 grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-muted-slate">
        {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
          <span key={d}>{d}</span>
        ))}
      </div>
      <div className="mt-2 grid grid-cols-7 gap-1 text-center text-[13px]">
        {cells.map((day, i) => {
          if (day === null) return <span key={i} />;
          const active = sepDays.includes(day);
          return (
            <span
              key={i}
              className={`flex aspect-square items-center justify-center rounded-md ${
                active
                  ? "bg-navy font-bold text-white"
                  : "text-muted-slate/60"
              }`}
            >
              {day}
            </span>
          );
        })}
      </div>
    </div>
  );
}

function CourseCard({ c, i }: { c: Course; i: number }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-border-blue bg-white shadow-sm transition-shadow duration-150 hover:shadow-lg">
      {c.badge && (
        <div className="bg-teal/15 px-4 py-1.5 text-[12px] font-bold text-teal-deep">{c.badge}</div>
      )}
      <div
        className="relative h-44 bg-cover bg-center"
        style={{ backgroundImage: `url(${courseImages[i % courseImages.length]})` }}
      >
        <div className="absolute left-3 top-3 flex gap-2">
          <span className="rounded-full bg-navy px-3 py-1 text-[11px] font-semibold text-white">
            Intensive
          </span>
          <span className="rounded-full bg-white px-3 py-1 text-[11px] font-semibold text-navy">
            {c.transmission}
          </span>
        </div>
      </div>
      <div className="flex">
        <div className="flex w-20 shrink-0 flex-col items-center justify-center bg-navy py-6 text-white">
          <span className="font-display text-[28px] font-extrabold leading-none">{c.day}</span>
          <span className="mt-1 text-[12px] uppercase tracking-wide">{c.month}</span>
        </div>
        <div className="flex-1 p-5">
          <h3 className="font-display text-[15px] font-bold text-navy">{c.title}</h3>
          <div className="mt-3 space-y-2 text-[13px] text-muted-slate">
            <p className="flex items-center gap-2">
              <Clock size={14} className="text-teal-deep" /> {c.hours} hours ({c.dateLabel})
            </p>
            <p className="flex items-center gap-2">
              <MapPin size={14} className="text-teal-deep" /> {c.location} · {c.postcode}
            </p>
            <p className="flex items-center gap-2">
              <User size={14} className="text-teal-deep" /> With <span className="font-semibold text-navy">Ken D</span>
            </p>
          </div>
          <div className="mt-4 flex items-center justify-between">
            <span className="font-display text-[18px] font-extrabold text-navy">From {gbp(c.price)}</span>
            <Link to="/courses" className="text-[14px] font-bold text-teal-deep">
              Book Now
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

const Courses = () => {
  const [postcode, setPostcode] = useState("");
  const [radius, setRadius] = useState("10 miles");
  const [transmission, setTransmission] = useState("Any");
  const [hourFilter, setHourFilter] = useState("All");
  const [sort, setSort] = useState("Soonest");
  const [view, setView] = useState<"grid" | "list">("grid");

  const visible = useMemo(() => {
    let list = [...courses];
    const hv = hourValue[hourFilter];
    if (hv !== null) list = list.filter((c) => c.hours === hv);
    if (transmission !== "Any") list = list.filter((c) => c.transmission === transmission);
    if (sort === "Price: Low to high") list.sort((a, b) => a.price - b.price);
    return list;
  }, [hourFilter, transmission, sort]);

  return (
    <div className="min-h-screen bg-pale-blue">
      <Header />

      {/* Filter bar */}
      <div className="border-b border-border-blue bg-white">
        <div className="mx-auto max-w-[1200px] px-6 py-5">
          <label className="text-[13px] font-semibold text-navy">Postcode</label>
          <div className="mt-2 flex flex-col gap-3 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <MapPin size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-slate" />
              <input
                type="text"
                value={postcode}
                onChange={(e) => setPostcode(e.target.value)}
                placeholder="Enter your postcode"
                aria-label="Postcode"
                className="w-full rounded-lg border border-border-blue py-3 pl-9 pr-3 text-[15px] text-navy outline-none focus:border-teal-deep"
              />
            </div>
            <button
              type="button"
              aria-label="Use my location"
              className="flex items-center justify-center rounded-lg border border-border-blue p-3 text-muted-slate hover:border-navy"
            >
              <Crosshair size={18} />
            </button>
            <select
              value={radius}
              onChange={(e) => setRadius(e.target.value)}
              aria-label="Search radius"
              className="rounded-lg border border-border-blue px-3 py-3 text-[14px] text-navy outline-none focus:border-teal-deep"
            >
              {radiusOptions.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
            <select
              value={transmission}
              onChange={(e) => setTransmission(e.target.value)}
              aria-label="Transmission"
              className="rounded-lg border border-border-blue px-3 py-3 text-[14px] text-navy outline-none focus:border-teal-deep"
            >
              <option>Any</option>
              <option>Manual</option>
              <option>Automatic</option>
            </select>
            <button
              type="button"
              className="flex items-center justify-center gap-2 rounded-lg bg-navy px-6 py-3 text-[14px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
            >
              <Search size={16} /> Search
            </button>
          </div>

          <div className="mt-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
            <div className="flex flex-wrap gap-2">
              {hourFilters.map((h) => (
                <button
                  key={h}
                  type="button"
                  onClick={() => setHourFilter(h)}
                  className={`rounded-full border px-4 py-1.5 text-[13px] font-semibold transition-colors duration-150 ${
                    hourFilter === h
                      ? "border-navy bg-navy text-white"
                      : "border-border-blue bg-white text-navy hover:border-navy"
                  }`}
                >
                  {h}
                </button>
              ))}
            </div>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              aria-label="Sort by"
              className="rounded-lg border border-border-blue px-3 py-2 text-[14px] text-navy outline-none focus:border-teal-deep"
            >
              {sortOptions.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main content */}
      <main className="mx-auto max-w-[1200px] px-6 py-8">
        <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
          <aside className="hidden lg:block">
            <Calendar />
          </aside>

          <div>
            <div className="flex items-center justify-between">
              <p className="text-[15px] font-semibold text-navy">Showing all courses</p>
              <div className="flex gap-2">
                <button
                  type="button"
                  aria-label="Grid view"
                  onClick={() => setView("grid")}
                  className={`rounded-lg border p-2 ${
                    view === "grid" ? "border-navy bg-navy text-white" : "border-border-blue text-muted-slate"
                  }`}
                >
                  <LayoutGrid size={16} />
                </button>
                <button
                  type="button"
                  aria-label="List view"
                  onClick={() => setView("list")}
                  className={`rounded-lg border p-2 ${
                    view === "list" ? "border-navy bg-navy text-white" : "border-border-blue text-muted-slate"
                  }`}
                >
                  <List size={16} />
                </button>
              </div>
            </div>

            {visible.length === 0 ? (
              <div className="mt-8 rounded-2xl border border-border-blue bg-white p-16 text-center text-[15px] text-muted-slate">
                No courses found in this area — try a different postcode.
              </div>
            ) : (
              <div
                className={`mt-6 grid gap-6 ${
                  view === "grid" ? "sm:grid-cols-2" : "grid-cols-1"
                }`}
              >
                {visible.map((c, i) => (
                  <CourseCard key={c.id} c={c} i={i} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Courses;
