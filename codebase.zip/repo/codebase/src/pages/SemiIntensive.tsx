import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Gauge, CalendarClock, Users, TrendingUp } from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";

const heroCards = [
  { Icon: Gauge, title: "Balanced pace", sub: "Pass in 4–8 weeks" },
  { Icon: CalendarClock, title: "Flexible schedule", sub: "Fits around work or studies" },
  { Icon: Users, title: "Popular choice", sub: "Most learners choose this option" },
];

const SemiIntensive = () => {
  const navigate = useNavigate();
  const [address, setAddress] = useState("");

  return (
    <div className="min-h-screen bg-pale-blue">
      <Header />

      {/* Hero */}
      <section className="bg-navy">
        <div className="mx-auto max-w-[1200px] px-6 py-16">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-[12px] font-bold uppercase tracking-wide text-teal">
            <TrendingUp size={14} /> Most popular choice
          </span>
          <h1 className="mt-6 font-display text-[40px] font-extrabold leading-[1.05] tracking-[-0.02em] text-white sm:text-[54px]">
            Semi-intensive courses.
          </h1>
          <p className="mt-5 max-w-xl text-[16px] leading-relaxed text-white/70">
            The best of both worlds — faster than weekly lessons but with time to absorb what you've
            learned between sessions.
          </p>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {heroCards.map(({ Icon, title, sub }) => (
              <div key={title} className="flex items-center gap-3 rounded-xl bg-white/5 p-4 ring-1 ring-white/10">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-teal/20 text-teal">
                  <Icon size={20} />
                </span>
                <div className="leading-tight">
                  <p className="text-[15px] font-bold text-white">{title}</p>
                  <p className="text-[13px] text-white/70">{sub}</p>
                </div>
              </div>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              navigate("/courses");
            }}
            className="mt-8 flex max-w-lg items-center gap-2 rounded-2xl bg-white p-2 shadow-lg"
          >
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Type your pick up address.."
              aria-label="Pick-up address"
              className="flex-1 bg-transparent px-3 py-2 text-[15px] text-navy outline-none"
            />
            <button
              type="submit"
              className="flex items-center gap-2 rounded-xl bg-navy px-5 py-3 text-[13px] font-bold uppercase tracking-wide text-white transition-opacity duration-150 hover:opacity-90"
            >
              <Search size={16} /> Search
            </button>
          </form>
        </div>
      </section>

      {/* Empty state */}
      <main className="mx-auto max-w-[1200px] px-6 py-14">
        <div className="rounded-2xl border border-border-blue bg-white p-16 text-center text-[15px] text-muted-slate">
          No semi-intensive courses found in this area — try a different postcode.
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default SemiIntensive;
