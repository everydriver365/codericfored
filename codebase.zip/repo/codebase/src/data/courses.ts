export type Course = {
  id: string;
  day: string;
  month: string;
  title: string;
  hours: number;
  dateLabel: string;
  location: string;
  postcode: string;
  price: number;
  transmission: "Automatic" | "Manual";
  badge?: string;
};

// Driver photo backgrounds reused across course cards
export const courseImages = [
  "/075c2_1786609104289-hero.png",
  "/871a2_1786608716177-hero.png",
  "/0c178_1786606402120-hero.png",
];

export const courses: Course[] = [
  { id: "c1", day: "22", month: "JUN", title: "10 hour driving lessons", hours: 10, dateLabel: "22 Jun", location: "Winchester", postcode: "SO22", price: 522, transmission: "Automatic" },
  { id: "c2", day: "22", month: "JUN", title: "8 hour driving lessons", hours: 8, dateLabel: "22 Jun", location: "Winchester", postcode: "SO22", price: 12121, transmission: "Automatic" },
  { id: "c3", day: "26", month: "JUN", title: "Test in a week", hours: 28, dateLabel: "26 Jun", location: "Winchester", postcode: "SO22", price: 200, transmission: "Automatic" },
  { id: "c4", day: "1", month: "JUL", title: "800 hour driving lessons", hours: 800, dateLabel: "1 Jul", location: "Eastleigh", postcode: "SO30", price: 2000, transmission: "Automatic" },
  { id: "c5", day: "1", month: "JUL", title: "Test in a week", hours: 28, dateLabel: "1 Jul", location: "Winchester", postcode: "SO22", price: 99999, transmission: "Automatic" },
  { id: "c6", day: "1", month: "AUG", title: "10 hour driving lessons", hours: 10, dateLabel: "1 Aug", location: "Blackburn", postcode: "BB1 9LP", price: 2000, transmission: "Automatic" },
  { id: "c7", day: "17", month: "AUG", title: "10 hour driving lessons", hours: 10, dateLabel: "17 Aug", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic" },
  { id: "c8", day: "17", month: "AUG", title: "10 hour driving lessons", hours: 10, dateLabel: "17 Aug", location: "Winchester", postcode: "SO22", price: 1, transmission: "Automatic" },
  { id: "c9", day: "18", month: "AUG", title: "10 hour driving lessons", hours: 10, dateLabel: "18 Aug", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic" },
  { id: "c10", day: "19", month: "AUG", title: "10 hour driving lessons", hours: 10, dateLabel: "19 Aug", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic" },
  { id: "c11", day: "20", month: "AUG", title: "10 hour driving lessons", hours: 10, dateLabel: "20 Aug", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic" },
  { id: "c12", day: "21", month: "AUG", title: "10 hour driving lessons", hours: 10, dateLabel: "21 Aug", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic" },
  { id: "c13", day: "27", month: "AUG", title: "8 hour driving lessons", hours: 8, dateLabel: "27 Aug", location: "Eastleigh", postcode: "SO30", price: 9000, transmission: "Automatic" },
  { id: "c14", day: "27", month: "AUG", title: "10 hour driving lessons", hours: 10, dateLabel: "27 Aug", location: "Winchester", postcode: "SO22", price: 1, transmission: "Automatic" },
  { id: "c15", day: "7", month: "SEP", title: "Test in a week", hours: 28, dateLabel: "7 Sep", location: "Eastleigh", postcode: "SO30", price: 2000, transmission: "Automatic" },
  { id: "c16", day: "17", month: "SEP", title: "10 hour driving lessons", hours: 10, dateLabel: "17 Sep", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic", badge: "Available today" },
  { id: "c17", day: "18", month: "SEP", title: "10 hour driving lessons", hours: 10, dateLabel: "18 Sep", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic", badge: "Available tomorrow" },
  { id: "c18", day: "21", month: "SEP", title: "10 hour driving lessons", hours: 10, dateLabel: "21 Sep", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic", badge: "Available this week" },
  { id: "c19", day: "22", month: "SEP", title: "10 hour driving lessons", hours: 10, dateLabel: "22 Sep", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic", badge: "Available this week" },
  { id: "c20", day: "23", month: "SEP", title: "10 hour driving lessons", hours: 10, dateLabel: "23 Sep", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic", badge: "Available this week" },
  { id: "c21", day: "29", month: "SEP", title: "10 hour driving lessons", hours: 10, dateLabel: "29 Sep", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic" },
  { id: "c22", day: "30", month: "SEP", title: "10 hour driving lessons", hours: 10, dateLabel: "30 Sep", location: "Eastleigh", postcode: "SO30", price: 500, transmission: "Automatic" },
];

export const gbp = (n: number) => `£${n.toLocaleString("en-GB")}`;
