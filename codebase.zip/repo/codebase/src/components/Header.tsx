import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ChevronDown, Menu, X } from "lucide-react";

type NavChild = { label: string; to: string };
type NavGroup = { label: string; children: NavChild[] };

const dropdowns: NavGroup[] = [
  {
    label: "Our Solution",
    children: [
      { label: "Intensive Courses", to: "/intensives" },
      { label: "Semi-Intensive", to: "/semi-intensive" },
      { label: "Weekly lessons", to: "/courses" },
      { label: "Test swap", to: "/test-swap" },
      { label: "Theory test", to: "/theory" },
      { label: "Bespoke enquiries", to: "/bespoke" },
      { label: "See all courses", to: "/courses" },
    ],
  },
  {
    label: "We Work With",
    children: [
      { label: "Learner drivers", to: "/courses" },
      { label: "Driving instructors", to: "/instructors" },
    ],
  },
  {
    label: "Learn",
    children: [
      { label: "News & Tips", to: "/news" },
      { label: "Reviews", to: "/reviews" },
      { label: "FAQs", to: "/faqs" },
      { label: "About", to: "/about" },
      { label: "Contact", to: "/contact" },
    ],
  },
];

const mobileLinks: NavChild[] = [
  { label: "Intensive Courses", to: "/intensives" },
  { label: "Semi-Intensive", to: "/semi-intensive" },
  { label: "Weekly lessons", to: "/courses" },
  { label: "Test swap", to: "/test-swap" },
  { label: "Theory test", to: "/theory" },
  { label: "Bespoke enquiries", to: "/bespoke" },
  { label: "See all courses", to: "/courses" },
  { label: "Learner drivers", to: "/courses" },
  { label: "Driving instructors", to: "/instructors" },
  { label: "Bespoke enquiries", to: "/bespoke" },
  { label: "Test swap", to: "/test-swap" },
  { label: "News & Tips", to: "/news" },
  { label: "Reviews", to: "/reviews" },
  { label: "FAQs", to: "/faqs" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
];

function DropdownItem({ group }: { group: NavGroup }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onDocClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDocClick);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  const openNow = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };
  const closeSoon = () => {
    closeTimer.current = setTimeout(() => setOpen(false), 120);
  };

  return (
    <div
      ref={ref}
      className="relative"
      onMouseEnter={openNow}
      onMouseLeave={closeSoon}
    >
      <button
        type="button"
        role="button"
        aria-haspopup="true"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1 text-[16px] text-navy hover:text-teal-deep transition-colors duration-150"
      >
        {group.label}
        <ChevronDown
          size={16}
          className={`transition-transform duration-150 ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && (
        <div className="absolute left-1/2 top-full z-50 mt-3 w-60 -translate-x-1/2 rounded-xl border border-border-blue bg-white p-2 shadow-xl shadow-navy/5">
          {group.children.map((child, i) => (
            <Link
              key={`${child.label}-${i}`}
              to={child.to}
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-2 text-[15px] text-muted-slate hover:bg-pale-blue hover:text-navy transition-colors duration-150"
            >
              {child.label}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  return (
    <header className="sticky top-0 z-40 h-[81px] w-full border-b border-border-blue bg-white">
      <div className="mx-auto flex h-full max-w-[1200px] items-center justify-between px-6">
        <Link to="/" aria-label="EveryDriver" className="shrink-0">
          <img
            src="/c2eda_ED_logo_for_checkfront_colors.png"
            alt="EveryDriver"
            className="h-10 w-auto"
          />
        </Link>

        <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
          {dropdowns.slice(0, 2).map((g) => (
            <DropdownItem key={g.label} group={g} />
          ))}
          <Link
            to="/courses?view=pricing"
            className="text-[16px] text-navy hover:text-teal-deep transition-colors duration-150"
          >
            Pricing
          </Link>
          <DropdownItem group={dropdowns[2]} />
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Link
            to="/courses"
            className="rounded-lg bg-navy px-5 py-2.5 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
          >
            Find a course
          </Link>
          <Link
            to="/login"
            className="rounded-lg border border-border-blue px-5 py-2.5 text-[15px] font-bold text-navy transition-colors duration-150 hover:border-navy"
          >
            Sign in
          </Link>
        </div>

        <button
          type="button"
          aria-label="Menu"
          onClick={() => setMobileOpen(true)}
          className="lg:hidden"
        >
          <Menu size={28} className="text-navy" />
        </button>
      </div>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex flex-col bg-white lg:hidden">
          <div className="flex h-[81px] shrink-0 items-center justify-between border-b border-border-blue px-6">
            <Link to="/" aria-label="EveryDriver" onClick={() => setMobileOpen(false)}>
              <img
                src="/c2eda_ED_logo_for_checkfront_colors.png"
                alt="EveryDriver"
                className="h-10 w-auto"
              />
            </Link>
            <button type="button" aria-label="Close menu" onClick={() => setMobileOpen(false)}>
              <X size={28} className="text-navy" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto">
            {mobileLinks.map((link, i) => (
              <Link
                key={`${link.label}-${i}`}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className="block border-b border-border-blue px-6 py-4 text-[18px] text-navy"
              >
                {link.label}
              </Link>
            ))}
            <div className="flex flex-col gap-3 p-6">
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  navigate("/courses");
                }}
                className="rounded-lg bg-navy px-5 py-3 text-center text-[15px] font-bold text-white"
              >
                Find a course
              </button>
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  navigate("/login");
                }}
                className="rounded-lg border border-border-blue px-5 py-3 text-center text-[15px] font-bold text-navy"
              >
                Sign in
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
