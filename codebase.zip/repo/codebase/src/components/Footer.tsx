import { useState } from "react";
import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Linkedin, Youtube, Star } from "lucide-react";

type Col = { title: string; links: { label: string; to?: string; href?: string }[] };

const columns: Col[] = [
  {
    title: "Learners",
    links: [
      { label: "Find instructor", to: "/courses" },
      { label: "Intensive", to: "/intensives" },
      { label: "Semi-intensive", to: "/semi-intensive" },
      { label: "Test swap", to: "/test-swap" },
      { label: "Theory test", to: "/theory" },
      { label: "Reviews", to: "/reviews" },
      { label: "FAQs", to: "/faqs" },
    ],
  },
  {
    title: "Instructors",
    links: [
      { label: "Join DSM", href: "https://dsm.everydriver.co.uk" },
      { label: "Sign in to DSM", to: "/login" },
      { label: "For instructors", to: "/instructors" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", to: "/about" },
      { label: "Contact", to: "/contact" },
      { label: "News", to: "/news" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", to: "/privacy" },
      { label: "Terms of Service", to: "/terms" },
      { label: "Returns & Refunds", to: "/returns" },
    ],
  },
];

const socials = [
  { label: "Facebook", href: "https://facebook.com/everydriveruk", Icon: Facebook },
  { label: "Twitter", href: "https://twitter.com/everydriveruk", Icon: Twitter },
  { label: "Instagram", href: "https://instagram.com/everydriveruk", Icon: Instagram },
  { label: "LinkedIn", href: "https://linkedin.com/company/everydriveruk", Icon: Linkedin },
  { label: "YouTube", href: "https://youtube.com/@everydriveruk", Icon: Youtube },
];

export default function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setEmail("");
  };

  return (
    <footer className="bg-footer-bg text-footer-text">
      <div className="mx-auto max-w-[1200px] px-6 py-14">
        {/* Top: logo + socials */}
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
          <img
            src="/64b2a_ed_checkfront_colors_transparent.png"
            alt="EveryDriver"
            className="h-10 w-auto"
          />
          <div className="flex items-center gap-3">
            {socials.map(({ label, href, Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener"
                aria-label={label}
                className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-teal-deep shadow-sm transition-transform duration-150 hover:-translate-y-0.5"
              >
                <Icon size={18} />
              </a>
            ))}
          </div>
        </div>

        {/* Columns */}
        <div className="mt-12 grid grid-cols-2 gap-8 md:grid-cols-4">
          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="font-display text-[14px] font-bold text-footer-text">{col.title}</h4>
              <ul className="mt-4 space-y-3">
                {col.links.map((link, i) => (
                  <li key={`${link.label}-${i}`}>
                    {link.href ? (
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener"
                        className="text-[15px] text-footer-muted transition-colors duration-150 hover:text-footer-accent"
                      >
                        {link.label}
                      </a>
                    ) : (
                      <Link
                        to={link.to!}
                        className="text-[15px] text-footer-muted transition-colors duration-150 hover:text-footer-accent"
                      >
                        {link.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="my-10 h-px w-full bg-footer-border" />

        {/* Newsletter + badges */}
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
          <div>
            <h4 className="font-display text-[16px] font-bold text-footer-text">
              Subscribe to our newsletter
            </h4>
            <p className="mt-2 max-w-md text-[15px] text-footer-muted">
              Get tips, offers and updates to help you pass your test and book with confidence.
            </p>
            <form onSubmit={onSubmit} className="mt-4 flex max-w-md flex-col gap-3 sm:flex-row">
              <input
                type="email"
                name="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                aria-label="Enter your email"
                className="flex-1 rounded-lg border border-footer-border bg-white px-4 py-3 text-[15px] text-navy outline-none focus:border-teal-deep"
              />
              <button
                type="submit"
                className="rounded-lg bg-navy px-6 py-3 text-[15px] font-bold text-white transition-opacity duration-150 hover:opacity-90"
              >
                Subscribe Now
              </button>
            </form>
            {subscribed && (
              <p className="mt-3 text-[14px] font-semibold text-teal-deep">
                Thanks — you're subscribed!
              </p>
            )}
            <p className="mt-3 text-[13px] text-footer-muted">
              By subscribing you agree to our{" "}
              <Link to="/privacy" className="text-footer-accent underline">
                Privacy Policy.
              </Link>
            </p>
          </div>

          <div className="flex flex-wrap items-stretch gap-4 lg:justify-end">
            <div className="flex flex-col items-center justify-center rounded-xl border border-footer-border bg-white px-8 py-5">
              <span className="font-display text-2xl font-extrabold text-navy">4.9</span>
              <span className="mt-1 flex text-amber">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={14} fill="currentColor" strokeWidth={0} />
                ))}
              </span>
              <span className="mt-1 text-[13px] text-footer-muted">Rated by 6,499+ learners</span>
            </div>
            <div className="flex flex-col items-center justify-center rounded-xl border border-footer-border bg-white px-8 py-5 text-center">
              <span className="text-[15px] font-bold text-navy">Secure payments</span>
              <span className="mt-1 text-[13px] text-footer-muted">Klarna · Clearpay</span>
              <span className="text-[13px] text-footer-muted">Credit / Debit card</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-footer-border">
        <div className="mx-auto flex max-w-[1200px] flex-col items-center justify-between gap-3 px-6 py-6 text-[14px] text-footer-muted sm:flex-row">
          <span>Copyright © 2026 EveryDriver Ltd</span>
          <div className="flex flex-wrap items-center gap-5">
            <Link to="/terms" className="hover:text-footer-accent">
              Terms of Service
            </Link>
            <Link to="/privacy" className="hover:text-footer-accent">
              Privacy Policy
            </Link>
            <Link to="/returns" className="hover:text-footer-accent">
              Returns & Refunds
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
